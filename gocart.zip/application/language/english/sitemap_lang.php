<?php
$lang['sitemap_page_title'] = 'Sitemap Generator';
$lang['error_sitemap_generate'] = 'An error encountred when generating the XML file';
$lang['success_sitemap_generate'] = 'Sitemap XML file has been generated';