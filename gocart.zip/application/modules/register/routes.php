<?php
$router->map('GET|POST', '/register', 'GoCart\Controller\Register#index');