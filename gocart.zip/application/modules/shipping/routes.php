<?php

$router->map('GET|POST', '/admin/shipping', 'GoCart\Controller\AdminShipping#index');