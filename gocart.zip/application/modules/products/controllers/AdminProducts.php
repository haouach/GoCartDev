<?php namespace GoCart\Controller;
/**
 * AdminProducts Class
 *
 * @package     GoCart
 * @subpackage  Controllers
 * @category    AdminProducts
 * @author      Clear Sky Designs
 * @link        http://gocartdv.com
 */

class AdminProducts extends Admin { 
    
    private $use_inventory = false;
    
    public function __construct()
    {       
        parent::__construct();
        
        \CI::auth()->check_access('Admin', true);
        
        \CI::load()->model(array('Products'));
        \CI::load()->helper('form');
        \CI::lang()->load('product');
    }

    public function index($rows=15, $order_by="name", $sort_order="ASC", $code=0, $page=0)
    {
        
        $data['page_title'] = lang('products');
        
        $data['code']       = $code;
        $term               = false;
        $category_id        = false;
        
        //get the category list for the drop menu
        $data['categories'] = \CI::Categories()->get_categories_tiered();
        
        $post               = \CI::input()->post(null, false);
        \CI::load()->model('Search');
        if($post)
        {
            $term = json_encode($post);
            $code = \CI::Search()->record_term($term);
            $data['code'] = $code;
        }
        elseif ($code)
        {
            $term = \CI::Search()->get_term($code);
        }
        
        //store the search term
        $data['term'] = $term;
        $data['order_by'] = $order_by;
        $data['sort_order'] = $sort_order;
        $data['rows'] = $rows;
        $data['page'] = $page;
        
        $data['products']   = \CI::Products()->products(array('term'=>$term, 'order_by'=>$order_by, 'sort_order'=>$sort_order, 'rows'=>$rows, 'page'=>$page));

        //total number of products
        $data['total']      = \CI::Products()->products(array('term'=>$term, 'order_by'=>$order_by, 'sort_order'=>$sort_order), true);

        
        \CI::load()->library('pagination');
        
        $config['base_url']         = site_url('admin/products/'.$order_by.'/'.$sort_order.'/'.$code.'/');
        $config['total_rows']       = $data['total'];
        $config['per_page']         = $rows;
        $config['uri_segment']      = 7;
        $config['first_link']       = 'First';
        $config['first_tag_open']   = '<li>';
        $config['first_tag_close']  = '</li>';
        $config['last_link']        = 'Last';
        $config['last_tag_open']    = '<li>';
        $config['last_tag_close']   = '</li>';

        $config['full_tag_open']    = '<div class="pagination"><ul>';
        $config['full_tag_close']   = '</ul></div>';
        $config['cur_tag_open']     = '<li class="active"><a href="#">';
        $config['cur_tag_close']    = '</a></li>';
        
        $config['num_tag_open']     = '<li>';
        $config['num_tag_close']    = '</li>';
        
        $config['prev_link']        = '&laquo;';
        $config['prev_tag_open']    = '<li>';
        $config['prev_tag_close']   = '</li>';

        $config['next_link']        = '&raquo;';
        $config['next_tag_open']    = '<li>';
        $config['next_tag_close']   = '</li>';
        
        \CI::pagination()->initialize($config);
        
        $this->view('products', $data);
    }
    
    //basic category search
    public function product_autocomplete()
    {
        $name   = trim(\CI::input()->post('name'));
        $limit  = \CI::input()->post('limit');
        
        if(empty($name))
        {
            echo json_encode([]);
        }
        else
        {
            $results    = \CI::Products()->product_autocomplete($name, $limit);
            
            $return     = [];
            
            foreach($results as $r)
            {
                $return[$r->id] = $r->name;
            }
            echo json_encode($return);
        }
        
    }
    
    public function bulk_save()
    {
        $products   = \CI::input()->post('product');
        
        if(!$products)
        {
            \CI::session()->set_flashdata('error',  lang('error_bulk_no_products'));
            redirect('admin/products');
        }
                
        foreach($products as $id=>$product)
        {
            $product['id']  = $id;
            \CI::Products()->save($product);
        }
        
        \CI::session()->set_flashdata('message', lang('message_bulk_update'));
        redirect('admin/products');
    }
    
    public function form($id = false, $duplicate = false)
    {
        $this->product_id   = $id;
        \CI::load()->library('form_validation');
        \CI::load()->model(array('ProductOptions', 'Categories', 'DigitalProducts'));
        \CI::lang()->load('digital_product');
        \CI::form_validation()->set_error_delimiters('<div class="error">', '</div>');
        
        $data['categories']     = \CI::Categories()->get_categories_tiered();
        $data['file_list']      = \CI::DigitalProducts()->get_list();

        $data['page_title']     = lang('product_form');

        //default values are empty if the product is new
        $data['id']                 = '';
        $data['sku']                = '';
        $data['primary_category']   = '';
        $data['name']               = '';
        $data['slug']               = '';
        $data['description']        = '';
        $data['excerpt']            = '';
        $data['price']              = '';
        $data['saleprice']          = '';
        $data['weight']             = '';
        $data['track_stock']        = '';
        $data['seo_title']          = '';
        $data['meta']               = '';
        $data['shippable']          = '';
        $data['taxable']            = '';
        $data['fixed_quantity']     = '';
        $data['quantity']           = '';
        $data['enabled']            = '';
        $data['google_feed']        = '';
        $data['related_products']   = [];
        $data['product_categories'] = [];
        $data['images']             = [];
        $data['product_files']      = [];

        //create the photos array for later use
        $data['photos']     = [];

        if ($id)
        {   
            // get the existing file associations and create a format we can read from the form to set the checkboxes
            $pr_files       = \CI::DigitalProducts()->get_associations_by_product($id);
            foreach($pr_files as $f)
            {
                $data['product_files'][]  = $f->file_id;
            }
            
            // get product & options data
            $data['ProductOptions']    = \CI::ProductOptions()->getProductOptions($id);
            $product                    = \CI::Products()->find($id, true);

            //if the product does not exist, redirect them to the product list with an error
            if (!$product)
            {
                \CI::session()->set_flashdata('error', lang('error_not_found'));
                redirect('admin/products');
            }
            
            //helps us with the slug generation
            $this->product_name = \CI::input()->post('slug', $product->slug);
            
            //set values to db values
            $data['id']                 = $id;
            $data['sku']                = $product->sku;
            $data['primary_category']   = $product->primary_category;
            $data['name']               = $product->name;
            $data['seo_title']          = $product->seo_title;
            $data['meta']               = $product->meta;
            $data['slug']               = $product->slug;
            $data['description']        = $product->description;
            $data['excerpt']            = $product->excerpt;
            $data['price']              = $product->price;
            $data['saleprice']          = $product->saleprice;
            $data['weight']             = $product->weight;
            $data['track_stock']        = $product->track_stock;
            $data['shippable']          = $product->shippable;
            $data['quantity']           = $product->quantity;
            $data['taxable']            = $product->taxable;
            $data['fixed_quantity']     = $product->fixed_quantity;
            $data['enabled']            = $product->enabled;
            $data['google_feed']        = json_decode($product->google_feed);

            
            //make sure we haven't submitted the form yet before we pull in the images/related products from the database
            if(!\CI::input()->post('submit'))
            {
                
                $data['product_categories'] = [];
                foreach($product->categories as $product_category)
                {
                    $data['product_categories'][] = $product_category->id;
                }
                
                $data['related_products']   = $product->related_products;
                $data['images']             = (array)json_decode($product->images);
            }
        }
        
        //if $data['related_products'] is not an array, make it one.
        if(!is_array($data['related_products']))
        {
            $data['related_products']   = [];
        }
        if(!is_array($data['product_categories']))
        {
            $data['product_categories'] = [];
        }

        
        //no error checking on these
        \CI::form_validation()->set_rules('caption', 'Caption');
        \CI::form_validation()->set_rules('primary_photo', 'Primary');

        \CI::form_validation()->set_rules('sku', 'lang:sku', 'trim');
        \CI::form_validation()->set_rules('seo_title', 'lang:seo_title', 'trim');
        \CI::form_validation()->set_rules('meta', 'lang:meta_data', 'trim');
        \CI::form_validation()->set_rules('name', 'lang:name', 'trim|required|max_length[64]');
        \CI::form_validation()->set_rules('slug', 'lang:slug', 'trim');
        \CI::form_validation()->set_rules('description', 'lang:description', 'trim');
        \CI::form_validation()->set_rules('excerpt', 'lang:excerpt', 'trim');
        \CI::form_validation()->set_rules('price', 'lang:price', 'trim|numeric|floatval');
        \CI::form_validation()->set_rules('saleprice', 'lang:saleprice', 'trim|numeric|floatval');
        \CI::form_validation()->set_rules('weight', 'lang:weight', 'trim|numeric|floatval');
        \CI::form_validation()->set_rules('track_stock', 'lang:track_stock', 'trim|numeric');
        \CI::form_validation()->set_rules('quantity', 'lang:quantity', 'trim|numeric');
        \CI::form_validation()->set_rules('shippable', 'lang:shippable', 'trim|numeric');
        \CI::form_validation()->set_rules('taxable', 'lang:taxable', 'trim|numeric');
        \CI::form_validation()->set_rules('fixed_quantity', 'lang:fixed_quantity', 'trim|numeric');
        \CI::form_validation()->set_rules('enabled', 'lang:enabled', 'trim|numeric');

        /*
        if we've posted already, get the photo stuff and organize it
        if validation comes back negative, we feed this info back into the system
        if it comes back good, then we send it with the save item
        
        submit button has a value, so we can see when it's posted
        */
        
        if($duplicate)
        {
            $data['id'] = false;
        }
        if(\CI::input()->post('submit'))
        {
            //reset the product options that were submitted in the post
            $data['ProductOptions']    = \CI::input()->post('option');
            $data['related_products']   = \CI::input()->post('related_products');
            $data['product_categories'] = \CI::input()->post('categories');
            $data['images']             = \CI::input()->post('images');
            $data['product_files']      = \CI::input()->post('downloads');
            
        }
        
        if (\CI::form_validation()->run() == FALSE)
        {
            $this->view('product_form', $data);
        }
        else
        {
            \CI::load()->helper('text');
            
            //first check the slug field
            $slug = \CI::input()->post('slug');
            
            //if it's empty assign the name field
            if(empty($slug) || $slug=='')
            {
                $slug = \CI::input()->post('name');
            }
            
            $slug   = url_title(convert_accented_characters($slug), '-', TRUE);
            
            //validate the slug
            $slug = ($id) ? \CI::Products()->validate_slug($slug, $product->id) : \CI::Products()->validate_slug($slug);


            $save['id']                 = $id;
            $save['sku']                = \CI::input()->post('sku');
            $save['name']               = \CI::input()->post('name');
            $save['seo_title']          = \CI::input()->post('seo_title');
            $save['meta']               = \CI::input()->post('meta');
            $save['description']        = \CI::input()->post('description');
            $save['excerpt']            = \CI::input()->post('excerpt');
            $save['price']              = \CI::input()->post('price');
            $save['saleprice']          = \CI::input()->post('saleprice');
            $save['weight']             = \CI::input()->post('weight');
            $save['track_stock']        = \CI::input()->post('track_stock');
            $save['fixed_quantity']     = \CI::input()->post('fixed_quantity');
            $save['quantity']           = \CI::input()->post('quantity');
            $save['shippable']          = \CI::input()->post('shippable');
            $save['taxable']            = \CI::input()->post('taxable');
            $save['enabled']            = \CI::input()->post('enabled');
            (config_item('google_product_fields')) ? $save['google_feed'] = json_encode(\CI::input()->post('google_feed')) : '';
            $post_images                = \CI::input()->post('images');
            
            $save['slug']               = $slug;

            
            if($primary = \CI::input()->post('primary_image'))
            {
                if($post_images)
                {
                    foreach($post_images as $key => &$pi)
                    {
                        if($primary == $key)
                        {
                            $pi['primary']  = true;
                            continue;
                        }
                    }   
                }
                
            }
            
            $save['images'] = json_encode($post_images);
            
            
            if(\CI::input()->post('related_products'))
            {
                $save['related_products'] = json_encode(\CI::input()->post('related_products'));
            }
            else
            {
                $save['related_products'] = '';
            }
            
            //save categories
            $categories = \CI::input()->post('categories');
            if(!$categories)
            {
                $categories = [];
            }
            
             //(\CI::input()->post('primary_category')) ? \CI::input()->post('primary_category') : 0;
            if(!\CI::input()->post('primary_category') && $categories)
            {
                $save['primary_category'] = $categories[0];
            }
            elseif(!\CI::input()->post('primary_category') && !$categories)
            {
                $save['primary_category'] = 0;  
            }
            else
            {
                $save['primary_category'] = \CI::input()->post('primary_category');
            }            
            
            
            // format options
            $options = [];
            if(\CI::input()->post('option'))
            {
                foreach (\CI::input()->post('option') as $option)
                {
                    $options[]  = $option;
                }

            }   
            
            // save product 
            $product_id = \CI::Products()->save($save, $options, $categories);
            
            // add file associations
            // clear existsing
            \CI::DigitalProducts()->disassociate(false, $product_id);
            // save new
            $downloads = \CI::input()->post('downloads');
            if(is_array($downloads))
            {
                foreach($downloads as $d)
                {
                    \CI::DigitalProducts()->associate($d, $product_id);
                }
            }
            
            \CI::session()->set_flashdata('message', lang('message_saved_product'));

            //go back to the product list
            redirect('admin/products');
        }
    }
    
    public function product_image_form()
    {
        $data['file_name'] = false;
        $data['error']  = false;
        $this->partial('iframe/product_image_uploader', $data);
    }
    
    public function product_image_upload()
    {
        $data['file_name'] = false;
        $data['error']  = false;
        
        $config['allowed_types'] = 'gif|jpg|png';
        //$config['max_size']   = config_item('size_limit');
        $config['upload_path'] = 'uploads/images/full';
        $config['encrypt_name'] = true;
        $config['remove_spaces'] = true;

        \CI::load()->library('upload', $config);
        
        if ( \CI::upload()->do_upload())
        {
            $upload_data    = \CI::upload()->data();
            
            \CI::load()->library('image_lib');
           
            $config['image_library'] = 'gd2';
            $config['source_image'] = 'uploads/images/full/'.$upload_data['file_name'];
            $config['new_image']    = 'uploads/images/medium/'.$upload_data['file_name'];
            $config['maintain_ratio'] = TRUE;
            $config['width'] = 600;
            $config['height'] = 500;
            \CI::image_lib()->initialize($config);
            \CI::image_lib()->resize();
            \CI::image_lib()->clear();

            //small image
            $config['image_library'] = 'gd2';
            $config['source_image'] = 'uploads/images/medium/'.$upload_data['file_name'];
            $config['new_image']    = 'uploads/images/small/'.$upload_data['file_name'];
            $config['maintain_ratio'] = TRUE;
            $config['width'] = 235;
            $config['height'] = 235;
            \CI::image_lib()->initialize($config); 
            \CI::image_lib()->resize();
            \CI::image_lib()->clear();

            //cropped thumbnail
            $config['image_library'] = 'gd2';
            $config['source_image'] = 'uploads/images/small/'.$upload_data['file_name'];
            $config['new_image']    = 'uploads/images/thumbnails/'.$upload_data['file_name'];
            $config['maintain_ratio'] = TRUE;
            $config['width'] = 150;
            $config['height'] = 150;
            \CI::image_lib()->initialize($config);  
            \CI::image_lib()->resize(); 
            \CI::image_lib()->clear();

            $data['file_name']  = $upload_data['file_name'];
        }
        
        if(\CI::upload()->display_errors() != '')
        {
            $data['error'] = \CI::upload()->display_errors();
        }
        $this->partial('iframe/product_image_uploader', $data);
    }
    
    public function delete($id = false)
    {
        if ($id)
        {   
            $product    = \CI::Products()->find($id);
            //if the product does not exist, redirect them to the customer list with an error
            if (!$product)
            {
                \CI::session()->set_flashdata('error', lang('error_not_found'));
                redirect('admin/products');
            }
            else
            {

                //if the product is legit, delete them
                \CI::Products()->delete_product($id);

                \CI::session()->set_flashdata('message', lang('message_deleted_product'));
                redirect('admin/products');
            }
        }
        else
        {
            //if they do not provide an id send them to the product list page with an error
            \CI::session()->set_flashdata('error', lang('error_not_found'));
            redirect('admin/products');
        }
    }
}