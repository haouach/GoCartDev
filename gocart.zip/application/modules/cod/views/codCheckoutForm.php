<div class="page-header">
    <?php echo lang('COD');?>
</div>