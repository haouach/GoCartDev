<?php

$router->map('GET|POST', '/admin/payments', 'GoCart\Controller\AdminPayments#index');